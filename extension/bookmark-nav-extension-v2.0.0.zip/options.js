const runtimeApi = typeof browser !== 'undefined' ? browser : chrome;
const permissionsApi = runtimeApi && runtimeApi.permissions ? runtimeApi.permissions : null;

function storageGet(area, keys) {
  return new Promise(resolve => chrome.storage[area].get(keys, resolve));
}

function storageSet(area, items) {
  return new Promise(resolve => chrome.storage[area].set(items, resolve));
}

function storageRemove(area, keys) {
  return new Promise(resolve => chrome.storage[area].remove(keys, resolve));
}

function sanitizeUrl(value) {
  if (!value) return '';
  let url = value.trim();
  if (url.endsWith('/')) {
    url = url.replace(/\/+$/, '');
  }
  if (!/^https?:\/\//i.test(url)) {
    url = `https://${url}`;
  }
  try {
    const parsed = new URL(url);
    return parsed.origin;
  } catch (error) {
    return '';
  }
}

async function updateStatusView() {
  const { serverUrl = '', username = '' } = await storageGet('local', ['serverUrl', 'username']);
  const statusInfo = document.getElementById('status-info');
  const logoutBtn = document.getElementById('logout-btn');
  const serverInput = document.getElementById('server-url');
  const usernameInput = document.getElementById('username');

  if (serverUrl) {
    serverInput.value = serverUrl;
  }
  if (username) {
    usernameInput.value = username;
  }

  // 向服务器验证认证状态
  if (serverUrl) {
    try {
      const response = await fetch(`${serverUrl}/api/auth/status`, {
        method: 'GET',
        credentials: 'include'
      });
      const result = await response.json();

      if (result.authenticated) {
        statusInfo.textContent = `已连接到 ${serverUrl}，账号 ${result.user?.username || username || '管理员'}，已登录。`;
        logoutBtn.style.display = 'block';
      } else {
        statusInfo.textContent = `服务器地址已配置：${serverUrl}，会话已过期或未登录，请重新登录。`;
        logoutBtn.style.display = 'none';
      }
    } catch (error) {
      statusInfo.textContent = `服务器地址已配置：${serverUrl}，无法连接到服务器验证状态。`;
      logoutBtn.style.display = 'none';
    }
  } else {
    statusInfo.textContent = '请配置服务器地址并登录。';
    logoutBtn.style.display = 'none';
  }
}

function displayConnectionStatus(message, type = 'info') {
  const status = document.getElementById('connection-status');
  status.textContent = message;
  status.classList.remove('hidden', 'status-connected', 'status-disconnected');
  if (type === 'success') {
    status.classList.add('status-connected');
  } else if (type === 'error') {
    status.classList.add('status-disconnected');
  }
}

async function requestHostPermission(origin) {
  if (!permissionsApi || !permissionsApi.request) {
    return true;
  }

  const details = { origins: [`${origin}/*`] };
  const length = permissionsApi.request.length;

  if (length >= 2) {
    return new Promise(resolve => {
      permissionsApi.request(details, granted => {
        resolve(Boolean(granted));
      });
    });
  }

  try {
    const result = permissionsApi.request(details);
    if (result && typeof result.then === 'function') {
      const granted = await result;
      return Boolean(granted);
    }
    return Boolean(result);
  } catch (error) {
    console.warn('Permission request failed:', error);
    return false;
  }
}

async function removePreviousPermissions(exceptOrigin) {
  if (!permissionsApi || !permissionsApi.getAll || !permissionsApi.remove) {
    return;
  }

  let current = { origins: [] };
  const length = permissionsApi.getAll.length;

  if (length >= 1) {
    current = await new Promise(resolve => permissionsApi.getAll(resolve));
  } else {
    try {
      const result = permissionsApi.getAll();
      current = result && typeof result.then === 'function' ? await result : (result || current);
    } catch (error) {
      console.warn('Get permissions failed:', error);
    }
  }

  const toRemove = (current.origins || []).filter(origin => origin !== `${exceptOrigin}/*`);
  if (toRemove.length === 0) {
    return;
  }

  const removeLength = permissionsApi.remove.length;
  if (removeLength >= 2) {
    await new Promise(resolve => permissionsApi.remove({ origins: toRemove }, () => resolve()));
  } else {
    try {
      const result = permissionsApi.remove({ origins: toRemove });
      if (result && typeof result.then === 'function') {
        await result;
      }
    } catch (error) {
      console.warn('Remove permissions failed:', error);
    }
  }
}

async function handleLogin(event) {
  event.preventDefault();

  const serverInput = document.getElementById('server-url');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const loginBtn = document.getElementById('login-btn');
  const loginText = document.getElementById('login-text');

  const serverUrl = sanitizeUrl(serverInput.value);
  const username = usernameInput.value.trim();
  const password = passwordInput.value;

  if (!serverUrl || !username || !password) {
    displayConnectionStatus('请填写所有必填项。', 'error');
    return;
  }

  loginBtn.disabled = true;
  loginText.textContent = '登录中...';
  displayConnectionStatus('正在请求权限...', 'info');

  const granted = await requestHostPermission(serverUrl);
  if (!granted) {
    displayConnectionStatus('未获得访问权限，无法连接服务器。', 'error');
    loginBtn.disabled = false;
    loginText.textContent = '登录并保存';
    return;
  }

  await removePreviousPermissions(serverUrl);

  displayConnectionStatus('正在连接服务器...', 'info');

  try {
    const response = await fetch(`${serverUrl}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      credentials: 'include',
      body: JSON.stringify({ username, password })
    });

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error('用户名或密码不正确。');
      }
      throw new Error('服务器返回错误，请检查地址并重试。');
    }

    const result = await response.json();
    if (!result.user) {
      throw new Error(result.error || '登录失败。');
    }

    await storageSet('local', {
      serverUrl,
      username
    });

    // 清除旧的 token 相关存储（兼容旧版本残留数据）
    await storageRemove('local', ['authToken', 'tokenExpiry', 'encryptedPassword', 'autoRenew']);

    passwordInput.value = '';
    displayConnectionStatus('登录成功，会话已建立。', 'success');
    await updateStatusView();
  } catch (error) {
    console.error('Login error:', error);
    displayConnectionStatus(error.message || '网络错误，请稍后重试。', 'error');
  } finally {
    loginBtn.disabled = false;
    loginText.textContent = '登录并保存';
  }
}

async function handleLogout() {
  const { serverUrl = '' } = await storageGet('local', ['serverUrl']);

  if (serverUrl) {
    try {
      await fetch(`${serverUrl}/api/auth/logout`, {
        method: 'POST',
        credentials: 'include'
      });
    } catch (error) {
      console.error('Logout error:', error);
    }
  }

  await storageRemove('local', ['authToken', 'tokenExpiry', 'encryptedPassword', 'autoRenew']);
  displayConnectionStatus('已登出。', 'info');
  updateStatusView();
}

async function init() {
  await updateStatusView();

  const { theme } = await storageGet('local', ['theme']);
  if (theme === 'dark') {
    document.body.classList.add('dark');
  }

  document.getElementById('settings-form').addEventListener('submit', handleLogin);
  document.getElementById('logout-btn').addEventListener('click', handleLogout);
}

document.addEventListener('DOMContentLoaded', init);
