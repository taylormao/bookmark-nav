let settings = {};
let categories = [];

function storageGet(area, keys) {
  return new Promise(resolve => chrome.storage[area].get(keys, resolve));
}

function storageSet(area, items) {
  return new Promise(resolve => chrome.storage[area].set(items, resolve));
}

async function loadSettings() {
  const result = await storageGet('local', ['serverUrl', 'username']);
  const { serverUrl = '', username = '' } = result;
  settings = { serverUrl, username };
  return settings;
}

function showSection(sectionId) {
  document.getElementById('auth-section').classList.add('hidden');
  document.getElementById('form-section').classList.add('hidden');
  document.getElementById('loading-section').classList.add('hidden');
  document.getElementById(sectionId).classList.remove('hidden');
}

function showStatus(message, type = 'info') {
  const statusEl = document.getElementById('status-message');
  statusEl.textContent = message;
  statusEl.className = `status-message status-${type}`;
  statusEl.classList.remove('hidden');

  setTimeout(() => {
    statusEl.classList.add('hidden');
  }, 4000);
}

async function checkAuth() {
  try {
    const response = await fetch(`${settings.serverUrl}/api/auth/status`, {
      method: 'GET',
      credentials: 'include'
    });
    const result = await response.json();
    return result.authenticated;
  } catch (error) {
    return false;
  }
}

async function loadCategories() {
  try {
    const response = await fetch(`${settings.serverUrl}/api/admin/categories`, {
      method: 'GET',
      credentials: 'include'
    });

    if (!response.ok) {
      throw new Error('Failed to load categories');
    }

    const result = await response.json();
    const rawCategories = result.categories || [];

    const categoryMap = new Map();
    rawCategories.forEach(cat => {
      categoryMap.set(cat.id, { ...cat });
    });

    categories = rawCategories.map(cat => {
      const base = categoryMap.get(cat.id);
      const segments = [];
      const visited = new Set();
      let current = base;

      while (current) {
        if (visited.has(current.id)) {
          break;
        }
        visited.add(current.id);
        segments.unshift(current.name);
        if (!current.parentId) {
          break;
        }
        current = categoryMap.get(current.parentId);
      }

      return {
        ...base,
        path: segments.join(' / ')
      };
    });

    const select = document.getElementById('category');
    select.innerHTML = '<option value="">选择分类...</option>';

    categories.forEach(cat => {
      const option = document.createElement('option');
      option.value = String(cat.id);
      option.textContent = cat.path || cat.name;
      select.appendChild(option);
    });

    if (categories.length > 0) {
      select.value = String(categories[0].id);
    }

    return true;
  } catch (error) {
    console.error('Failed to load categories:', error);
    return false;
  }
}

async function getCurrentTab() {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      resolve(tabs && tabs.length ? tabs[0] : null);
    });
  });
}

async function maybeUseContextInfo() {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'request-context-info' }, info => {
      if (chrome.runtime.lastError) {
        resolve(null);
        return;
      }
      resolve(info || null);
    });
  });
}

async function saveBookmark(event) {
  event.preventDefault();

  const title = document.getElementById('title').value.trim();
  const url = document.getElementById('url').value.trim();
  const description = document.getElementById('description').value.trim();
  const categoryId = document.getElementById('category').value;
  const isPrivate = document.getElementById('is-private').checked;

  if (!title || !url || !categoryId) {
    showStatus('请填写所有必填项', 'error');
    return;
  }

  const saveBtn = document.getElementById('save-btn');
  const saveText = document.getElementById('save-text');
  saveBtn.disabled = true;
  saveText.textContent = '保存中...';

  try {
    const response = await fetch(`${settings.serverUrl}/api/admin/bookmarks`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      credentials: 'include',
      body: JSON.stringify({
        title: title,
        url: url,
        description: description || null,
        icon: null,
        categoryId: parseInt(categoryId, 10),
        visibility: isPrivate ? 'private' : 'public'
      })
    });

    const result = await response.json();

    if (response.ok && result.bookmark) {
      showStatus('书签保存成功', 'success');
      setTimeout(() => {
        window.close();
      }, 1000);
    } else {
      showStatus(result.error || '保存失败', 'error');
      saveBtn.disabled = false;
      saveText.textContent = '保存书签';
    }
  } catch (error) {
    console.error('Save error:', error);
    showStatus('网络错误，请检查服务器地址', 'error');
    saveBtn.disabled = false;
    saveText.textContent = '保存书签';
  }
}

async function init() {
  showSection('loading-section');

  await loadSettings();

  if (!settings.serverUrl) {
    showSection('auth-section');
    return;
  }

  const authed = await checkAuth();
  if (!authed) {
    showSection('auth-section');
    return;
  }

  const categoriesLoaded = await loadCategories();
  if (!categoriesLoaded) {
    showSection('auth-section');
    return;
  }

  const contextInfo = await maybeUseContextInfo();
  const tab = contextInfo || await getCurrentTab();

  if (tab) {
    document.getElementById('title').value = tab.title || '';
    document.getElementById('url').value = tab.url || '';
  }

  showSection('form-section');
}

document.addEventListener('DOMContentLoaded', () => {
  init();

  document.getElementById('goto-options').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  document.getElementById('settings-btn').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  document.getElementById('bookmark-form').addEventListener('submit', saveBookmark);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.serverUrl)) {
    init();
  }
});
